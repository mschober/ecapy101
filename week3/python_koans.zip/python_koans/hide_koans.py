from koan_activator import hide_koans

hide_koans()
