from koan_activator import show_active_koans

show_active_koans()
