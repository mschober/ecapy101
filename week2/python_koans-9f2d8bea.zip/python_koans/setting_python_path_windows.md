### Setting windows python path walkthrough
* [ Week 1 setting path ](https://github.com/mschober/ecapy101/wiki/week01_topic01)
