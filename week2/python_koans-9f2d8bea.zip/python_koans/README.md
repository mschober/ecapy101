### Python Koans
* delta2
