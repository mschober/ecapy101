#!/usr/bin/env python
# -*- coding: utf-8 -*-

an_attribute = 1984